﻿(function () {
    "use strict";

    angular.module('app')
        .service('appState', function ($location) {
            // manages the current application state

            this.getCurrentUrl = function () {
                return $location.path();
            };
        });
})();