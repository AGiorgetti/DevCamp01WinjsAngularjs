﻿(function () {
    "use strict";

    angular.module('app')
        .factory('angularWinjsLocalSettings', function () {
            var appData = Windows.Storage.ApplicationData.current;
            var localSettings = appData.localSettings;

            function clear() {
                appData.clearAsync(Windows.Storage.ApplicationDataLocality.local);
            }

            return {
                values: localSettings.values,
                clear: clear
            }
        });
})();