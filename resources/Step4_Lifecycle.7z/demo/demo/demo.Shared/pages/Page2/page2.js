﻿/// <reference path="../../Scripts/angular.js" />

(function () {

    angular.module('app')
    .controller('page2Controller', function ($scope) {
        $scope.data = { content: 'some content from page 2' };
    });

})();