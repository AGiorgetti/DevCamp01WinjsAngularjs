﻿/// <reference path="../../Scripts/angular.js" />

(function () {

    angular.module('app')
    .controller('page1Controller', function ($scope) {
        $scope.data = { content: 'some content from page 1' };
    });

})();