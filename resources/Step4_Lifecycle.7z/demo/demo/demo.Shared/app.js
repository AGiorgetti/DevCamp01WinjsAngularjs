﻿/// <reference path="Scripts/angular.js" />
(function () {
    angular.module('app', ['ngRoute', 'winjs'])
        .run(function (appState, angularWinjsLifecycle) {
            //resolve the appState and the lifecycle management service to initialize them
        })
        .controller('shell', function ($scope, angularWinjsRouterAdatper, $location) {
            // resolve the navigation framework bridge service to keep things in sync

            $scope.data = {
                title: 'Navigation Demo'
            };
            $scope.goToPage1 = function () {
                $location.path('/page1');
            };
            $scope.goToPage2 = function () {
                $location.path('/page2');
            };
        });
})();