﻿/// <reference path="Scripts/angular.js" />
(function () {
    angular.module('app')
        .config(['$routeProvider', function ($routeProvider) {
            $routeProvider
                .when('/page1', { templateUrl: '/pages/page1/page1.html', controller: 'page1Controller', data: {} })
                .when('/page2', { templateUrl: '/pages/page2/page2.html', controller: 'page2Controller', data: {} })

                .otherwise({ redirectTo: '/page1' });
        }]);
})();

